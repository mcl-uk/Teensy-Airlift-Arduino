
// WiFiNINA_Pinout_Generic.h

//#warning You have to modify pin usage according to actual connection
#define PINS_COUNT  (60u)

// Teensy <--> Airlift wiring definitions

#define SPIWIFI		SPI	// use SPI or SPI1
//
//  SIG		SPI	SPI1
//  ----	---	----
//  MISO	12	 1
//  MOSI	11	 26
//  SCK		13	 27

#define NINA_GPIO0  	15 	// was 40 // 'GP0' not optional for server apps
#define NINA_RESETN 	14 	// was 41 // 'RST' active low (1ms pulse)
#define NINA_ACK    	 9	// 'BUSY'
#define SPIWIFI_SS  	10	// 'CS'

#define SPIWIFI_ACK	NINA_ACK
#define SPIWIFI_RESET	NINA_RESETN
#define NINA_GPIOIRQ	NINA_GPIO0



// b/tooth stuff

#define SerialHCI	Serial2
// TxD2 = 8, RxD2 = 7

#define NINA_CTS	NINA_ACK	// in from Airlift BUSY (as CTS) - active low to request remote tx
#define NINA_RTS	NINA_GPIO0	// out to Airlift GP0 (as RTS) - active low to request remote rx

// Note SPIWIFI_SS pin controls bluetooth/wifi mode at reset:
// hold low for b/tooth, high for WiFi.
// Hold state for 750ms from trailing edge of --__RST__--
// Likewise ensure GP0 is held high over reset-time to avoid bootloader mode


