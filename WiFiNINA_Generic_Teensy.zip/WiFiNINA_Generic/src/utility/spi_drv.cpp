/**********************************************************************************************************************************
  spi_drv.cpp - Library for Arduino WiFiNINA module/shield.

  Based on and modified from WiFiNINA library https://www.arduino.cc/en/Reference/WiFiNINA
  to support nRF52, SAMD21/SAMD51, STM32F/L/H/G/WB/MP1, Teensy, etc. boards besides Nano-33 IoT, MKRWIFI1010, MKRVIDOR400, etc.

  Built by Khoi Hoang https://github.com/khoih-prog/WiFiNINA_Generic
  Licensed under MIT license

  Copyright (c) 2018 Arduino SA. All rights reserved.
  Copyright (c) 2011-2014 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Version: 1.8.15-1

  Version Modified By   Date      Comments
  ------- -----------  ---------- -----------
  1.5.0      K Hoang    27/03/2020 Initial coding to support other boards besides Nano-33 IoT, MKRWIFI1010, MKRVIDOR4000, etc.
                                   such as Arduino Mega, Teensy, SAMD21, SAMD51, STM32, etc
  ...
  1.8.13     K Hoang    03/08/2021 Sync with WiFiNINA v1.8.13 : new FW v1.4.8. Add support to ADAFRUIT_MATRIXPORTAL_M4_EXPRESS
  1.8.14-1   K Hoang    25/11/2021 Fix examples to support ATmega4809 such as UNO_WIFI_REV2 and NANO_EVERY
  1.8.14-2   K Hoang    31/12/2021 Add support to Nano_RP2040_Connect using arduino-pico core
  1.8.14-3   K Hoang    31/12/2021 Fix issue with UDP for Nano_RP2040_Connect using arduino-pico core
  1.8.14-4   K Hoang    01/05/2022 Fix bugs by using some PRs from original WiFiNINA. Add WiFiMulti-related examples
  1.8.14-5   K Hoang    23/05/2022 Fix bug causing data lost when sending large files
  1.8.14-6   K Hoang    17/08/2022 Add support to Teensy 4.x using WiFiNINA AirLift. Fix minor bug
  1.8.14-7   K Hoang    11/11/2022 Modify WiFiWebServer example to avoid crash in arduino-pico core
  1.8.15-0   K Hoang    14/11/2022 Fix severe limitation to permit sending much larger data than total 4K
  1.8.15-1   K Hoang    18/11/2022 Using new WiFi101_Generic library to permit sending larger data than total 4K
 ***********************************************************************************************************************************/

// SJM May 2023: Removed dross, removed debug lines, simplified & stream-lined coding, fixed bugs.

#include "Arduino.h"
#include <SPI.h>
#include "spi_drv.h"
#include "pins_arduino.h"
#include "WiFi_Generic.h"
#include "WiFiNINA_Pinout_Generic.h"

static uint8_t SLAVESELECT = SPIWIFI_SS; 							// CS
static uint8_t SLAVEREADY  = SPIWIFI_ACK;						  // BUSY
static uint8_t SLAVERESET  = (uint8_t)SPIWIFI_RESET;  // RST
static bool    inverted_reset = false;

////////////////////////////////////////

#ifndef SPIWIFI
  #define SPIWIFI SPI
#endif

#ifndef NINA_GPIOIRQ
  #define NINA_GPIOIRQ    NINA_GPIO0
#endif

////////////////////////////////////////

bool SpiDrv::initialized = false;

extern WiFiClass WiFi;

////////////////////////////////////////

void SpiDrv::begin()
{
  if (SLAVERESET > PINS_COUNT)
  {
    inverted_reset = true;
    SLAVERESET = ~SLAVERESET;
  }
  pinMode(SLAVESELECT, OUTPUT);
  pinMode(SLAVEREADY, INPUT);
  pinMode(SLAVERESET, OUTPUT);
  pinMode(NINA_GPIO0, OUTPUT);
  digitalWrite(NINA_GPIO0, HIGH);
  digitalWrite(SLAVESELECT, HIGH);  // must have SS/CS high during RST for WiFi mode
  digitalWrite(SLAVERESET, inverted_reset ? HIGH : LOW);
  delay(1);
  digitalWrite(SLAVERESET, inverted_reset ? LOW : HIGH);
  delay(500);
  digitalWrite(NINA_GPIO0, LOW);
  pinMode(NINA_GPIOIRQ, INPUT);
  SPIWIFI.begin();
  initialized = true;
}

void SpiDrv::end()
{
  digitalWrite(SLAVERESET, inverted_reset ? HIGH : LOW);
  pinMode(SLAVESELECT, INPUT);
  SPIWIFI.end();
  initialized = false;
}

void SpiDrv::spiSlaveSelect()
{
  SPIWIFI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
  digitalWrite(SLAVESELECT, LOW);
  // wait for up to 5 ms for the NINA to indicate it is not ready for transfer
  // the timeout is only needed for the case when the shield or module is not present
  for (unsigned long start = millis(); (digitalRead(SLAVEREADY) != HIGH) && (millis() - start) < 5;){};
}

void SpiDrv::spiSlaveDeselect()
{
  digitalWrite(SLAVESELECT, HIGH);
  SPIWIFI.endTransaction();
}

char SpiDrv::spiTransfer(volatile char data)
{
  return SPIWIFI.transfer(data);
}

int SpiDrv::waitSpiChar(unsigned char waitChar)
{
  int timeout = TIMEOUT_CHAR;
  unsigned char _readChar = 0;
  //
  do
  {
    _readChar = SPIWIFI.transfer(DUMMY_DATA); //get data byte
    if (_readChar == ERR_CMD)
    {
      WARN("Err cmd received\n");
      return -1;
    }
  } while ((timeout-- > 0) && (_readChar != waitChar));
  return  (_readChar == waitChar);
}


int SpiDrv::readAndCheckChar(char checkChar, char* readChar)
{
  *readChar = SPIWIFI.transfer(DUMMY_DATA);
  return (*readChar == checkChar);
}

char SpiDrv::readChar()
{
  return SPIWIFI.transfer(DUMMY_DATA);
}

#define WAIT_START_CMD(x) waitSpiChar(START_CMD)

#define IF_CHECK_START_CMD(x)             \
  if (!WAIT_START_CMD(_data))             \
  {                                       \
    TOGGLE_TRIGGER()                      \
    WARN("Error waiting START_CMD");      \
    return 0;                             \
  } else                                  \

#define CHECK_DATA(check, x)              \
  if (!readAndCheckChar(check, &x))       \
  {                                       \
    TOGGLE_TRIGGER()                      \
    WARN("Reply error");                  \
    INFO2(check, (uint8_t)x);             \
    return 0;                             \
  }else                                   \

#define waitSlaveReady()  (digitalRead(SLAVEREADY) == LOW)
#define waitSlaveSign()   (digitalRead(SLAVEREADY) == HIGH)
#define waitSlaveSignalH() while(digitalRead(SLAVEREADY) != HIGH){}
#define waitSlaveSignalL() while(digitalRead(SLAVEREADY) != LOW){}

// NOT USED
void SpiDrv::waitForSlaveSign()
{
  while (!waitSlaveSign());
}

void SpiDrv::waitForSlaveReady()
{
  if (digitalRead(SLAVEREADY) == LOW) return;
  unsigned long start = millis();
  //while (!waitSlaveReady()) // digitalRead(SLAVEREADY) == LOW
  while (digitalRead(SLAVEREADY) != LOW)
  {
    if ((millis() - start) > 10000)
    {
      WiFi.feedWatchdog();
      start = millis();
    }
  }
}

void SpiDrv::getParam(uint8_t* param)
{
  *param = SPIWIFI.transfer(DUMMY_DATA);
}

int SpiDrv::waitResponseCmd(uint8_t cmd, uint8_t numParam, uint8_t* param, uint8_t* param_len)
{
  char _data = 0;
  int ii = 0;
  //
  IF_CHECK_START_CMD(_data)
  {
    CHECK_DATA(cmd | REPLY_FLAG, _data) {};
    CHECK_DATA(numParam, _data)
    {
      readParamLen8(param_len);
      for (ii = 0; ii < (*param_len); ++ii) param[ii] = SPIWIFI.transfer(DUMMY_DATA);
    }
    readAndCheckChar(END_CMD, &_data);
  }
  return 1;
}


int SpiDrv::waitResponseData16(uint8_t cmd, uint8_t* param, uint16_t* param_len)
{
  char _data = 0;
  uint16_t ii = 0;
  //
  IF_CHECK_START_CMD(_data)
  {
    CHECK_DATA(cmd | REPLY_FLAG, _data) {};
    uint8_t numParam = readChar();
    if (numParam != 0)
    {
      readParamLen16(param_len);
      for (ii = 0; ii < (*param_len); ++ii) param[ii] = SPIWIFI.transfer(DUMMY_DATA);
    }
    readAndCheckChar(END_CMD, &_data);
  }
  return 1;
}

int SpiDrv::waitResponseData8(uint8_t cmd, uint8_t* param, uint8_t* param_len)
{
  char _data = 0;
  int ii = 0;
	uint8_t numParam;
  //
  IF_CHECK_START_CMD(_data)
  {
    CHECK_DATA(cmd | REPLY_FLAG, _data) {};
    numParam = readChar();
    if (numParam != 0)
    {
      readParamLen8(param_len);
      for (ii = 0; ii < (*param_len); ++ii) param[ii] = SPIWIFI.transfer(DUMMY_DATA);
    }
    readAndCheckChar(END_CMD, &_data);
  }
  return 1;
}

int SpiDrv::waitResponseParams(uint8_t cmd, uint8_t numParam, tParam* params)
{
  char _data = 0;
  int i = 0, ii = 0;
	uint8_t _numParam;
  //
  IF_CHECK_START_CMD(_data)
  {
    CHECK_DATA(cmd | REPLY_FLAG, _data) {};
    _numParam = readChar();
    if (_numParam != 0)
    {
      for (i = 0; i < _numParam; ++i)
      {
        params[i].paramLen = readParamLen8();
        for (ii = 0; ii < params[i].paramLen; ++ii) params[i].param[ii] = SPIWIFI.transfer(DUMMY_DATA);
      }
    }
    else return 0;
    if (numParam != _numParam) return 0;
    readAndCheckChar(END_CMD, &_data);
  }
  return 1;
}

int SpiDrv::waitResponse(uint8_t cmd, uint8_t* numParamRead, uint8_t** params, uint8_t maxNumParams)
{
  char _data = 0;
  int i = 0, ii = 0;
  char *index[WL_SSID_MAX_LENGTH];
  uint8_t paramLen;
	//
  for (i = 0 ; i < WL_NETWORKS_LIST_MAXNUM ; i++) index[i] = (char *)params + WL_SSID_MAX_LENGTH * i;
  IF_CHECK_START_CMD(_data)
  {
    CHECK_DATA(cmd | REPLY_FLAG, _data) {};
    uint8_t numParam = readChar();
    if (numParam > maxNumParams) numParam = maxNumParams;
    *numParamRead = numParam;
    if (numParam != 0)
    {
      for (i = 0; i < numParam; ++i)
      {
        paramLen = readParamLen8();
        for (ii = 0; ii < paramLen; ++ii) index[i][ii] = (uint8_t)SPIWIFI.transfer(DUMMY_DATA);
        index[i][ii] = 0;
      }
    }
    else
    {
      readAndCheckChar(END_CMD, &_data);
      return 0;
    }
    readAndCheckChar(END_CMD, &_data);
  }
  return 1;
}

void SpiDrv::sendParamNoLen(uint8_t* param, size_t param_len, uint8_t lastParam)
{
  size_t i = 0;
  // Send Spi paramLen
  sendParamLen8(0);
  // Send Spi param data
  for (i = 0; i < param_len; ++i) SPIWIFI.transfer(param[i]);
  // if lastParam==1 Send Spi END CMD
  if (lastParam == 1) SPIWIFI.transfer(END_CMD);
}

void SpiDrv::sendParam(uint8_t* param, uint8_t param_len, uint8_t lastParam)
{
  int i = 0;
  // Send Spi paramLen
  SPIWIFI.transfer(param_len);
  // Send Spi param data
  for (i = 0; i < param_len; ++i) SPIWIFI.transfer(param[i]);
  // if lastParam==1 Send Spi END CMD
  if (lastParam == 1) SPIWIFI.transfer(END_CMD);
}

void SpiDrv::sendParamLen8(uint8_t param_len)
{
  SPIWIFI.transfer(param_len);  // Send Spi paramLen
}

void SpiDrv::sendParamLen16(uint16_t param_len)
{
  // Send Spi paramLen
  SPIWIFI.transfer((uint8_t)((param_len & 0xff00) >> 8));
  SPIWIFI.transfer((uint8_t)(param_len & 0xff));
}

uint8_t SpiDrv::readParamLen8(uint8_t* param_len)
{
  uint8_t _param_len = SPIWIFI.transfer(DUMMY_DATA);
  if (param_len != NULL) *param_len = _param_len;
  return _param_len;
}

uint16_t SpiDrv::readParamLen16(uint16_t* param_len)
{
  uint16_t _param_len = SPIWIFI.transfer(DUMMY_DATA) << 8 | (SPIWIFI.transfer(DUMMY_DATA) & 0xff);
  if (param_len != NULL) *param_len = _param_len;
  return _param_len;
}

void SpiDrv::sendBuffer(uint8_t* param, uint16_t param_len, uint8_t lastParam)
{
  uint16_t i = 0;
  // Send Spi paramLen
  sendParamLen16(param_len);
  // Send Spi param data
  for (i = 0; i < param_len; ++i) SPIWIFI.transfer(param[i]);
  // if lastParam==1 Send Spi END CMD
  if (lastParam == 1) SPIWIFI.transfer(END_CMD);
}

void SpiDrv::sendParam(uint16_t param, uint8_t lastParam)
{
  // Send Spi paramLen
  sendParamLen8(2);
  SPIWIFI.transfer((uint8_t)((param & 0xff00) >> 8));
  SPIWIFI.transfer((uint8_t)(param & 0xff));
  // if lastParam==1 Send Spi END CMD
  if (lastParam == 1) SPIWIFI.transfer(END_CMD);
}

/* Cmd Struct Message */
/* _________________________________________________________________________________  */
/*| START CMD | C/R  | CMD  |[TOT LEN]| N.PARAM | PARAM LEN | PARAM  | .. | END CMD | */
/*|___________|______|______|_________|_________|___________|________|____|_________| */
/*|   8 bit   | 1bit | 7bit |  8bit   |  8bit   |   8bit    | nbytes | .. |   8bit  | */
/*|___________|______|______|_________|_________|___________|________|____|_________| */

void SpiDrv::sendCmd(uint8_t cmd, uint8_t numParam)
{
  // Send Spi START CMD
  SPIWIFI.transfer(START_CMD);
  // Send Spi C + cmd
  SPIWIFI.transfer(cmd & ~(REPLY_FLAG));
  // Send Spi totLen
  //SPIWIFI.transfer(totLen);
  // Send Spi numParam
  SPIWIFI.transfer(numParam);
  // If numParam == 0 send END CMD
  if (numParam == 0) SPIWIFI.transfer(END_CMD);
}

int SpiDrv::available()
{
  return (digitalRead(NINA_GPIOIRQ) != LOW);
}

SpiDrv spiDrv;
